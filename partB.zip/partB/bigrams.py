#!/usr/bin/env python
import codecs
import sys
from nltk import bigrams
import collections
from operator import itemgetter
import re

infile = open("data1.txt")
out = codecs.open("vocabulary.txt",'a','utf8')
words = collections.Counter()
      
for line in infile:
        tokens = line.split()
	tokens = tokens[2:]
        ml_bigram = bigrams(tokens)
	words.update(ml_bigram)

sorted_words = sorted(words.iteritems(), key=itemgetter(0), reverse=False)
for word, count in sorted_words:
    if ( count >= 2 ):
    	for ml in word:
		out.write("%s " % ml)
	out.write("\n")
