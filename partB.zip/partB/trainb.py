#!/usr/bin/env python
from collections import Counter
import csv
import re
import collections
from operator import itemgetter
from six.moves import cPickle
from nltk import bigrams

# Read in the training data.
infile = open("data1.txt")

pos_count = 0.0
neg_count = 0.0

positive_text = ""
negative_text = ""

for line in infile:
    a = line.rstrip()
    c = a[0][0]
    a = a[2:]
    if ( c == '+' ):
	pos_count = pos_count + 1
	positive_text = positive_text + a + "\n"

    if ( c == '-' ):
	neg_count = neg_count + 1
	negative_text = negative_text + a + "\n"

infile.close()

prior1 = pos_count/(pos_count+neg_count)	
print("P(+):	%f\n" % prior1)

prior2 = neg_count/(pos_count+neg_count)	
print("P(-):	%f" % prior2)

def bigram_count_text(text):
  # Split text into words based on whitespace.  Simple but effective.
  tokens = re.split("\s+", text)
  # Count up the occurence of each bigram.
  words = bigrams(tokens)
  return Counter(words)

# Generate bigram word counts for negative tone.
negative_bigram_counts = bigram_count_text(negative_text)
# Generate bigram word counts for positive tone.
positive_bigram_counts = bigram_count_text(positive_text)

class ModelObj:
  
   def __init__(self, label, word, cond_prob):
      self.label = label
      self.word = word
      self.cond_prob = cond_prob
   
   def getobj(self):
     print(self.label + " " + str(self.word) + " " + str(self.cond_prob))

f = open('objectsb.save', 'wb')

voc_count = len(open('vocabulary.txt', 'r').read().split())

sorted_bigram_words_pos = sorted(positive_bigram_counts.iteritems(), key=itemgetter(0), reverse=False)
	
for word, count in sorted_bigram_words_pos:
	cond_prob = (count + 1.0)/(positive_text.count(word[0])+ voc_count)
	obj = ModelObj('+', word, cond_prob)
	cPickle.dump(obj, f, protocol=cPickle.HIGHEST_PROTOCOL)

sorted_bigram_words_neg = sorted(negative_bigram_counts.iteritems(), key=itemgetter(0), reverse=False)

for word, count in sorted_bigram_words_neg:
	cond_prob = (count + 1.0)/(negative_text.count(word[0]) + voc_count)
	obj = ModelObj('-', word, cond_prob)
	cPickle.dump(obj, f, protocol=cPickle.HIGHEST_PROTOCOL)

f.close()

#f = open('objectsb.save', 'rb')
#for i in range(3):
#	loaded_object = cPickle.load(f)
#	print(loaded_object.getobj())
#f.close()

