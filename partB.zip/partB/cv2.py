#!/usr/bin/env python
import re
from collections import Counter
from operator import itemgetter
import math
from six.moves import cPickle
from nltk import bigrams

infile = open("data1.txt")
training = infile.readlines()
infile.close()

infile = open("data1.txt")
numberOfLines = 0

for line in infile:
    numberOfLines += 1

num_folds = 10
subset_size = numberOfLines / num_folds
print(num_folds)

infile.close()

sum_accuracy = 0.0

for i in range(num_folds):
	testing_this_round = training[i*subset_size:(i*subset_size + subset_size)]
	training_this_round = training[:i*subset_size] + training[(i+1)*subset_size:]
#	print(i)
#	print(training_this_round)
#	print(testing_this_round)
	# train using training_this_round

	pos_count = 0.0
	neg_count = 0.0

	positive_text = ""
	negative_text = ""
	
	trainfile = open("trainb.txt", "w")
	trainfile.writelines (training_this_round)
	trainfile.close()

	trainfile = open("trainb.txt", "r")
	for line in trainfile:
		a = line.rstrip()
    		c = a[0][0]
    		a = a[2:]
		if ( c == '+' ):
			pos_count = pos_count + 1
			positive_text = positive_text + a + "\n"

		if ( c == '-' ):
			neg_count = neg_count + 1
			negative_text = negative_text + a + "\n"

	trainfile.close()

	prior1 = pos_count/(pos_count+neg_count)	
	print("P(+):	%f" % prior1)

	prior2 = neg_count/(pos_count+neg_count)		
	print("P(-):	%f" % prior2)

	pos_word_count = 0.0
	neg_word_count = 0.0

	def bigram_count_text(text):
  		# Split text into words based on whitespace.  Simple but effective.
  		tokens = re.split("\s+", text)
  		# Count up the occurence of each bigram.
  		words = bigrams(tokens)
  		return Counter(words)

	# Generate bigram word counts for negative tone.
	negative_bigram_counts = bigram_count_text(negative_text)
	# Generate bigram word counts for positive tone.
	positive_bigram_counts = bigram_count_text(positive_text)

	# class to save the model

	class ModelObj:
  
        	def __init__(self, label, word, cond_prob):
        		self.label = label
        		self.word = word
        		self.cond_prob = cond_prob

		def get_word(self):
			return self.word

		def get_label(self):
			return self.label

        	def get_cond_prob(self):
			return self.cond_prob

	f = open('objectscvb.save', 'wb')

	voc_count = len(open('vocabulary.txt', 'r').read().split())

	objlist = []
	sorted_bigram_words_pos = sorted(positive_bigram_counts.iteritems(), key=itemgetter(0), reverse=False)
	for word, count in sorted_bigram_words_pos:
		cond_prob = (count + 1.0)/(positive_text.count(word[0]) + voc_count)
		obj = ModelObj('+', word, cond_prob)
		objlist.append(obj)
#		cPickle.dump(obj, f, protocol=cPickle.HIGHEST_PROTOCOL)
		
	sorted_bigram_words_neg = sorted(negative_bigram_counts.iteritems(), key=itemgetter(0), reverse=False)
	for word, count in sorted_bigram_words_neg:
		cond_prob = (count + 1.0)/(negative_text.count(word[0]) + voc_count)
		obj = ModelObj('-', word, cond_prob)
		objlist.append(obj)

	cPickle.dump(objlist, f, protocol=cPickle.HIGHEST_PROTOCOL)

	f.close()

	# evaluate against testing_this_round

	testfile = open("testb.txt", "w")
	testfile.writelines (testing_this_round)
	testfile.close()
	
	tp = tn = fp = fn = 0.0
	
	testfile = open("testb.txt", "r")
	for line in testfile:
		a = line.rstrip()
		c = a[0][0]
    		a = a[2:]

		tokens = re.split("\s+", a)
		words = bigrams(tokens)

		f = open('objectscvb.save', 'rb')
		loaded_object = cPickle.load(f)
		f.close()

		posterior_pos = math.log(prior1)
		posterior_neg = math.log(prior2)	

		for w in words:
			flag = 0
			flag1 = 0
			for obj in loaded_object:
				if (w == obj.get_word() and obj.get_label() == '+'):
					posterior_pos = posterior_pos + math.log(obj.get_cond_prob())
					flag = 1
				if (w == obj.get_word() and obj.get_label() == '-'):
					posterior_neg = posterior_neg + math.log(obj.get_cond_prob())
					flag1 = 1
				if (flag == 1 and flag1 == 1):
					break

		if (posterior_pos >= posterior_neg):	
			if (c == '+'):
				tp = tp + 1	
			else:
				fp = fp + 1
		else:
			if (c == '-'):
				tn = tn + 1
			else:
				fn = fn + 1

	# save accuracy
	
	accuracy = (tp + tn)/(tp + tn + fp + fn)		
	print("Accuracy:	%f"  % accuracy)

	sum_accuracy = sum_accuracy + accuracy

# find mean accuracy over all rounds

avg_accuracy = sum_accuracy/10

print("Average Accuracy:	%f"  % avg_accuracy)

