#!/usr/bin/env python
import collections
from operator import itemgetter
import re

infile = open("data1.txt")
words = collections.Counter()

for line in infile:
    a = line.rstrip().lower()
    a = a[2:]
#    print a	
    words.update(a.split())
             
f = open("vocabulary.txt", "w")
                 
sorted_words = sorted(words.iteritems(), key=itemgetter(0), reverse=False)
for word, count in sorted_words:
    if ( count > 1 ):
    	f.write("%s\n" % word)
