#!/usr/bin/env python
import io
import re

textwords = open('data.txt', 'r').read().split()
stopwords = open('stopwords.txt', 'r').read().split()

def removeStopwords(textwords, stopwords):
    return [w for w in textwords if w not in stopwords]

f = open("data1.txt", "w")

with io.open('data.txt', 'r', encoding = 'utf8') as data:
	for line in data:
		a = line.rstrip().lower()
		c = a[0][0]
		a = a[1:]
		result = re.sub('[,/()]', ' ', a)
		result = re.sub('[^a-zA-Z|\\s+]', '', result)
		if ( c == '+' ):
			result = "+" + result
		if ( c == '-' ):
			result = "-" + result
		result = result.split()#creates a list of words
		b = removeStopwords(result, stopwords)
		for item in b:
    			f.write("%s " % item)	
		f.write("\n")

