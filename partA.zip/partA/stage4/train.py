#!/usr/bin/env python
from collections import Counter
import csv
import re
import collections
from operator import itemgetter
from six.moves import cPickle

# Read in the training data.
infile = open("data1.txt")

pos_count = 0.0
neg_count = 0.0

positive_text = ""
negative_text = ""

for line in infile:
    a = line.rstrip()
    c = a[0][0]
    a = a[2:]
    if ( c == '+' ):
	pos_count = pos_count + 1
	positive_text = positive_text + a + "\n"

    if ( c == '-' ):
	neg_count = neg_count + 1
	negative_text = negative_text + a + "\n"

infile.close()

prior1 = pos_count/(pos_count+neg_count)	
print("P(+):	%f\n" % prior1)

prior2 = neg_count/(pos_count+neg_count)	
print("P(-):	%f" % prior2)

pos_word_count = 0.0
neg_word_count = 0.0

pos_word_count = len(positive_text.split())
print(pos_word_count)

neg_word_count = len(negative_text.split())
print(neg_word_count)

def count_text(text):
  # Split text into words based on whitespace.  Simple but effective.
  words = re.split("\s+", text)
  # Count up the occurence of each word.
  return Counter(words)

# Generate word counts for negative tone.
negative_counts = count_text(negative_text)
# Generate word counts for positive tone.
positive_counts = count_text(positive_text)

class ModelObj:
  
   def __init__(self, label, word, cond_prob):
      self.label = label
      self.word = word
      self.cond_prob = cond_prob

f = open('objects.save', 'wb')

voc_count = len(open('vocabulary.txt', 'r').read().split())

sorted_words_pos = sorted(positive_counts.iteritems(), key=itemgetter(0), reverse=False)
for word, count in sorted_words_pos:
	cond_prob = (count + 1.0)/(pos_word_count + voc_count)
	obj = ModelObj('+', word, cond_prob)
	cPickle.dump(obj, f, protocol=cPickle.HIGHEST_PROTOCOL)

sorted_words_neg = sorted(negative_counts.iteritems(), key=itemgetter(0), reverse=False)
for word, count in sorted_words_neg:
	cond_prob = (count + 1.0)/(neg_word_count + voc_count)
	obj = ModelObj('-', word, cond_prob)
	cPickle.dump(obj, f, protocol=cPickle.HIGHEST_PROTOCOL)

f.close()

#f = open('objects.save', 'rb')
#loaded_objects = []
#for i in range(3):
#     loaded_objects.append(cPickle.load(f))
#print(loaded_objects)
#f.close()
